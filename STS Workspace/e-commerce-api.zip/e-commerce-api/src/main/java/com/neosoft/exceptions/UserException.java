package com.neosoft.exceptions;

public class UserException extends Exception{

	
	public UserException() {
		// TODO Auto-generated constructor stub
	}
	public UserException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	
	
	
	
}
