package com.neosoft.exceptions;

public class ProductException extends Exception{

	
	public ProductException() {
		// TODO Auto-generated constructor stub
	}
	public ProductException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	
	
	
	
}
