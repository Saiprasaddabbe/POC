package com.neosoft.exceptions;

public class CartException extends Exception{

	
	public CartException() {
		// TODO Auto-generated constructor stub
	}
	public CartException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}
	
	
	
	
	
}
