package com.neosoft.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.neosoft.models.Product;

@Service
public class ProductServiceImpl implements ProductService {

	@Override
	public Product registerNewProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProductById(Integer productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product updateProductById(Integer productId, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product deleteProductById(Integer productId) {
		// TODO Auto-generated method stub
		return null;
	}

}
