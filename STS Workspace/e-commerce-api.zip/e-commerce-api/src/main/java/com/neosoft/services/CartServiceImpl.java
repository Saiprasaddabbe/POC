package com.neosoft.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.neosoft.models.Product;
import com.neosoft.models.User;

@Service
public class CartServiceImpl implements CartService{

	@Override
	public Product getProductById(Integer productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product deleteProductById(Integer productId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllCartProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	
	
	
	
	
	
}
